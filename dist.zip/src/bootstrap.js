/* Zotero Wallpaper - bootstrap */

var ZoteroWallpaper;
var ZW_PANE_ID = 'zotero-wallpaper-pane';

function log(msg) {
	Zotero.debug('[Wallpaper] ' + msg);
}

function install() {}

function uninstall() {}

async function startup({ id, version, rootURI }, reason) {
	if (typeof Zotero === 'undefined') {
		return;
	}
	try {
		if (Zotero.initializationPromise) {
			await Zotero.initializationPromise;
		}
	}
	catch (e) {}

	try {
		Services.scriptloader.loadSubScript(rootURI + 'content/wallpaper.js');

		ZoteroWallpaper.rootURI = rootURI;
		ZoteroWallpaper.pluginID = id;
		ZoteroWallpaper.startup();

		// 让首选项面板里的脚本可以调用
		Zotero.Wallpaper = ZoteroWallpaper;

		await Zotero.PreferencePanes.register({
			pluginID: id,
			id: ZW_PANE_ID,
			src: rootURI + 'content/prefs.xhtml',
			scripts: [rootURI + 'content/prefs.js'],
			label: '背景壁纸',
			image: rootURI + 'icons/wallpaper.svg',
		});

		log('started (v' + version + ')');
	}
	catch (e) {
		Zotero.logError(e);
	}
}

function shutdown({ id, version, rootURI }, reason) {
	if (reason === APP_SHUTDOWN) {
		return;
	}
	try {
		if (ZoteroWallpaper) {
			ZoteroWallpaper.shutdown();
		}
	}
	catch (e) {
		Zotero.logError(e);
	}
	try {
		delete Zotero.Wallpaper;
	}
	catch (e) {}
	ZoteroWallpaper = undefined;
}

function onMainWindowLoad({ window }) {
	if (typeof ZoteroWallpaper === 'undefined' || !ZoteroWallpaper) {
		return;
	}
	try {
		ZoteroWallpaper.addToWindow(window);
	}
	catch (e) {
		Zotero.logError(e);
	}
}

function onMainWindowUnload({ window }) {
	if (typeof ZoteroWallpaper === 'undefined' || !ZoteroWallpaper) {
		return;
	}
	try {
		ZoteroWallpaper.removeFromWindow(window);
	}
	catch (e) {
		Zotero.logError(e);
	}
}
