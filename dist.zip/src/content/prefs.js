/*
 * Zotero Wallpaper - 首选项面板脚本
 * 运行在首选项窗口的沙箱里（sandboxPrototype = 首选项窗口）
 */
(function () {
	"use strict";

	let tries = 0;

	function $(id) {
		return document.getElementById(id);
	}

	function api() {
		try {
			if (typeof Zotero !== 'undefined' && Zotero.Wallpaper) {
				return Zotero.Wallpaper;
			}
		}
		catch (e) {}
		return null;
	}

	/** 当前首选项窗口，用作文件对话框的父窗口 */
	function parentWin() {
		try {
			return document.defaultView || window;
		}
		catch (e) {
			return null;
		}
	}

	function setValue(id, text) {
		let el = $(id);
		if (el) {
			el.setAttribute('value', String(text));
		}
	}

	function setStatus(text, kind) {
		let el = $('zw-status');
		if (!el) {
			return;
		}
		el.setAttribute('value', text || '');
		// 用颜色区分成功 / 失败
		let color = '';
		if (kind === 'error') {
			color = '#c0392b';
		}
		else if (kind === 'ok') {
			color = '#2d7d46';
		}
		el.style.color = color;
	}

	function shortName(path) {
		if (!path) {
			return '（未设置）';
		}
		let parts = String(path).split(/[\\\/]/);
		return parts[parts.length - 1] || path;
	}

	function humanSize(n) {
		if (!n || n < 0) {
			return '';
		}
		if (n < 1024) {
			return n + ' B';
		}
		if (n < 1024 * 1024) {
			return (n / 1024).toFixed(0) + ' KB';
		}
		return (n / 1024 / 1024).toFixed(1) + ' MB';
	}

	function syncUI() {
		let a = api();
		if (!a) {
			return;
		}

		let el = $('zw-enabled');
		if (el) {
			el.checked = !!a.getPref('enabled');
		}

		el = $('zw-auto');
		if (el) {
			el.checked = !!a.getPref('auto');
		}

		let opacity = a.getPref('opacity');
		el = $('zw-opacity');
		if (el) {
			el.value = String(opacity);
		}
		setValue('zw-opacity-v', opacity + '%');

		let blur = a.getPref('blur');
		el = $('zw-blur');
		if (el) {
			el.value = String(blur);
		}
		setValue('zw-blur-v', blur + ' px');

		el = $('zw-fit');
		if (el) {
			try {
				el.value = a.getPref('fit');
			}
			catch (e) {}
		}

		setValue('zw-current', shortName(a.getPref('image')));
		setValue('zw-dir', '文件夹：' + a.getDir());
	}

	/**
	 * 绑定「激活」事件。
	 * XUL 按钮正常走 command，但个别情况下（被包在 html 容器里、或改版后）只有 click 会冒泡，
	 * 两个都挂上，再用时间戳去重，保证点一下只执行一次。
	 */
	function onActivate(el, handler) {
		let last = 0;
		let fail = (e) => {
			setStatus('出错了：' + ((e && e.message) || e), 'error');
			try {
				Zotero.logError(e);
			}
			catch (e2) {}
		};
		let wrapped = (ev) => {
			let now = Date.now();
			if (now - last < 350) {
				return;
			}
			last = now;
			try {
				let ret = handler(ev);
				// 异步 handler 的异常要单独接
				if (ret && typeof ret.catch === 'function') {
					ret.catch(fail);
				}
			}
			catch (e) {
				fail(e);
			}
		};
		el.addEventListener('command', wrapped);
		el.addEventListener('click', wrapped);
	}

	/** 按钮禁用/启用（XUL 元素用属性更稳妥） */
	function setBusy(el, busy) {
		if (!el) {
			return;
		}
		if (busy) {
			el.setAttribute('disabled', 'true');
		}
		else {
			el.removeAttribute('disabled');
		}
	}

	/** 统一处理返回 {ok, path, error, cancelled} 的调用 */
	function report(res, okText, quietCancel) {
		if (!res) {
			return;
		}
		if (res.ok) {
			setStatus(okText(res), 'ok');
			return;
		}
		if (res.cancelled) {
			if (!quietCancel) {
				setStatus('已取消。', '');
			}
			return;
		}
		setStatus('出错了：' + (res.error || '未知错误'), 'error');
		try {
			Zotero.debug('[Wallpaper] 面板操作失败：' + res.error);
		}
		catch (e) {}
	}

	function bind() {
		let a = api();
		if (!a) {
			setStatus('插件内部对象没有加载成功，请重启 Zotero 后再试。', 'error');
			return;
		}

		// 注意：每个元素都用独立的常量，闭包里绝不能共用会被重新赋值的变量
		const elEnabled = $('zw-enabled');
		const elAuto = $('zw-auto');
		const elOpacity = $('zw-opacity');
		const elBlur = $('zw-blur');
		const elFit = $('zw-fit');
		const btnChoose = $('zw-btn-choose');
		const btnOpen = $('zw-btn-open');
		const btnRefresh = $('zw-btn-refresh');
		const btnDir = $('zw-btn-dir');
		const btnReset = $('zw-reset');

		if (elEnabled) {
			onActivate(elEnabled, () => {
				a.setPref('enabled', !!elEnabled.checked);
				a.refreshAll();
			});
		}

		if (elAuto) {
			onActivate(elAuto, () => {
				a.setPref('auto', !!elAuto.checked);
				a.refreshAll();
				setStatus(elAuto.checked
					? '已切换为「自动」：文件夹里最新的一张会生效。'
					: '已切换为「手动」：固定使用当前这张图。', '');
			});
		}

		if (elOpacity) {
			elOpacity.addEventListener('input', () => {
				let v = parseInt(elOpacity.value, 10);
				if (isNaN(v)) {
					v = 0;
				}
				a.setPref('opacity', v);
				setValue('zw-opacity-v', v + '%');
			});
		}

		if (elBlur) {
			elBlur.addEventListener('input', () => {
				let v = parseInt(elBlur.value, 10);
				if (isNaN(v)) {
					v = 0;
				}
				a.setPref('blur', v);
				setValue('zw-blur-v', v + ' px');
			});
		}

		if (elFit) {
			onActivate(elFit, () => {
				a.setPref('fit', elFit.value);
				a.refreshAll();
			});
		}

		// ---- 选择图片
		if (btnChoose) {
			onActivate(btnChoose, async () => {
				setStatus('正在打开文件选择器…', '');
				setBusy(btnChoose, true);
				let res;
				try {
					res = await a.chooseImage(parentWin());
				}
				catch (e) {
					res = { ok: false, error: (e && e.message) || String(e) };
					try {
						Zotero.logError(e);
					}
					catch (e2) {}
				}
				finally {
					setBusy(btnChoose, false);
				}
				report(res, (r) => {
					let extra = r.copied ? '（已复制到壁纸文件夹）' : '（已在壁纸文件夹中）';
					let size = humanSize(r.size);
					return '已应用：' + shortName(r.path) + extra + (size ? ' · ' + size : '');
				});
				syncUI();
			});
		}

		// ---- 打开文件夹
		if (btnOpen) {
			onActivate(btnOpen, async () => {
				let res;
				try {
					res = await a.openFolder();
				}
				catch (e) {
					res = { ok: false, error: (e && e.message) || String(e) };
				}
				report(res, (r) => '已打开：' + r.path);
			});
		}

		// ---- 刷新
		if (btnRefresh) {
			onActivate(btnRefresh, () => {
				a.refreshAll();
				syncUI();
				let img = a.getPref('image');
				if (img) {
					setStatus('已刷新，当前使用：' + shortName(img), 'ok');
				}
				else {
					setStatus('已刷新，但文件夹里还没有图片。点「选择图片…」或直接往文件夹里丢图。', 'error');
				}
			});
		}

		// ---- 更改文件夹
		if (btnDir) {
			onActivate(btnDir, async () => {
				setStatus('正在打开文件夹选择器…', '');
				setBusy(btnDir, true);
				let res;
				try {
					res = await a.chooseFolder(parentWin());
				}
				catch (e) {
					res = { ok: false, error: (e && e.message) || String(e) };
					try {
						Zotero.logError(e);
					}
					catch (e2) {}
				}
				finally {
					setBusy(btnDir, false);
				}
				report(res, (r) => {
					let img = r.image ? '，当前使用：' + shortName(r.image) : '，文件夹里还没有图片';
					return '壁纸文件夹已改为：' + r.path + img;
				});
				syncUI();
			});
		}

		// ---- 恢复默认外观
		if (btnReset) {
			onActivate(btnReset, () => {
				a.resetAppearance();
				syncUI();
				setStatus('外观已恢复默认（不透明度 55%、模糊 0、铺满）。', 'ok');
			});
		}
	}

	function init() {
		let root = $('zw-pane-root');
		if (!root) {
			if (tries++ < 300) {
				setTimeout(init, 40);
			}
			return;
		}
		if (root.getAttribute('data-zw-ready') === '1') {
			return;
		}
		root.setAttribute('data-zw-ready', '1');

		syncUI();
		bind();

		root.addEventListener('showing', () => syncUI());
	}

	setTimeout(init, 0);
})();
