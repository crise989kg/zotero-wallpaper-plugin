/*
 * Zotero Wallpaper
 * 在「条目列表」区域叠加一张背景壁纸，可调不透明度 / 模糊 / 填充方式。
 */

var ZoteroWallpaper = {
	PREFIX: 'extensions.zotero.wallpaper.',

	DEFAULTS: {
		enabled: true,
		dir: 'D:\\A aiwork\\zotero插件\\wallpapers',
		auto: true,
		image: '',
		opacity: 55,
		blur: 0,
		fit: 'cover',
		debug: false,
	},

	IMAGE_EXTS: ['jpg', 'jpeg', 'jfif', 'jpe', 'png', 'apng', 'webp', 'gif', 'bmp', 'avif', 'svg', 'ico'],

	MIME: {
		jpg: 'image/jpeg',
		jpeg: 'image/jpeg',
		jfif: 'image/jpeg',
		jpe: 'image/jpeg',
		png: 'image/png',
		apng: 'image/apng',
		webp: 'image/webp',
		gif: 'image/gif',
		bmp: 'image/bmp',
		avif: 'image/avif',
		svg: 'image/svg+xml',
		ico: 'image/x-icon',
	},

	STYLE_ID: 'zw-wallpaper-style',
	LAYER_ID: 'zw-wallpaper-layer',
	IMAGE_ID: 'zw-wallpaper-image',

	rootURI: null,
	pluginID: null,
	_windows: [],
	_observers: [],
	_cache: null,
	_refreshTimer: null,
	_watchTimer: null,
	_appliedSig: null,

	// ---------------------------------------------------------------- 生命周期

	log(msg) {
		try {
			Zotero.debug('[Wallpaper] ' + msg);
		}
		catch (e) {}
		// 调试模式（extensions.zotero.wallpaper.debug = true）下额外写日志文件，方便排查
		try {
			if (!this.getPref('debug')) {
				return;
			}
			let path = this.getDir().replace(/[\\\/]+$/, '') + '\\_wallpaper-debug.log';
			IOUtils.write(path, new Date().toISOString() + '  ' + msg + '\n', { mode: 'append' })
				.catch(() => {});
		}
		catch (e) {}
	},

	startup() {
		this.log('startup');
		this.ensureDir().catch(e => Zotero.logError(e));
		this._registerObservers();
		this._startWatcher();

		// 插件在 Zotero 启动后才加载时，onMainWindowLoad 可能已经错过了
		try {
			for (let win of Zotero.getMainWindows()) {
				this.addToWindow(win);
			}
		}
		catch (e) {
			Zotero.logError(e);
		}
	},

	shutdown() {
		for (let sym of this._observers) {
			try {
				Zotero.Prefs.unregisterObserver(sym);
			}
			catch (e) {}
		}
		this._observers = [];

		if (this._refreshTimer) {
			clearTimeout(this._refreshTimer);
			this._refreshTimer = null;
		}
		if (this._watchTimer) {
			clearInterval(this._watchTimer);
			this._watchTimer = null;
		}

		for (let win of Zotero.getMainWindows()) {
			this.removeFromWindow(win);
		}
		this._windows = [];
		this._cache = null;
	},

	// ------------------------------------------------------------------ 首选项

	getPref(key) {
		let def = this.DEFAULTS.hasOwnProperty(key) ? this.DEFAULTS[key] : undefined;
		let val;
		try {
			val = Zotero.Prefs.get(this.PREFIX + key, true);
		}
		catch (e) {
			val = undefined;
		}
		if (val === undefined || val === null) {
			return def;
		}
		if (typeof def === 'number') {
			let n = parseInt(val, 10);
			return isNaN(n) ? def : n;
		}
		if (typeof def === 'boolean') {
			return (typeof val === 'boolean') ? val : (val === 'true' || val === true);
		}
		return String(val);
	},

	setPref(key, value) {
		try {
			Zotero.Prefs.set(this.PREFIX + key, value, true);
		}
		catch (e) {
			Zotero.logError(e);
		}
	},

	_registerObservers() {
		let keys = ['enabled', 'dir', 'auto', 'opacity', 'blur', 'fit'];
		for (let key of keys) {
			try {
				let sym = Zotero.Prefs.registerObserver(
					this.PREFIX + key,
					() => this.refreshAll(),
					true
				);
				this._observers.push(sym);
			}
			catch (e) {
				Zotero.logError(e);
			}
		}
	},

	// -------------------------------------------------------------- 文件夹处理

	_startWatcher() {
		if (this._watchTimer) {
			return;
		}
		// 每隔几秒看一眼文件夹，往里面丢新图就能自动生效
		this._watchTimer = setInterval(() => {
			try {
				this._checkFolder();
			}
			catch (e) {
				Zotero.logError(e);
			}
		}, 5000);
	},

	_checkFolder() {
		if (!this.getPref('enabled') || !this.getPref('auto')) {
			return;
		}
		let newest = this._newestImage(this.getDir());
		if (!newest) {
			return;
		}
		if (this._fileSig(newest) === this._appliedSig) {
			return;
		}
		this.refreshAll();
	},

	_fileSig(path) {
		try {
			let f = Zotero.File.pathToFile(path);
			return path + '|' + f.lastModifiedTime;
		}
		catch (e) {
			return path;
		}
	},

	getDir() {
		return this.getPref('dir') || this.DEFAULTS.dir;
	},

	async ensureDir() {
		let dir = this.getDir();
		try {
			let f = Zotero.File.pathToFile(dir);
			if (f.exists() && f.isDirectory()) {
				return dir;
			}
			await Zotero.File.createDirectoryIfMissingAsync(dir);
			// 首次创建时放一份说明，方便知道往哪放图
			try {
				let readme = Zotero.File.pathToFile(dir);
				readme.append('把图片放进这个文件夹.txt');
				if (!readme.exists()) {
					await Zotero.File.putContentsAsync(
						readme.path,
						'把想当壁纸的图片（jpg / png / webp / gif / bmp / avif）直接放进这个文件夹即可。\n'
						+ '插件会自动使用「最近修改」的那一张；也可以到 Zotero「编辑 → 设置 → 背景壁纸」里手动选择。\n'
					);
				}
			}
			catch (e) {
				// 说明文件写不进去不影响功能
			}
		}
		catch (e) {
			Zotero.logError(e);
		}
		return dir;
	},

	_fileExists(path) {
		try {
			let f = Zotero.File.pathToFile(path);
			return f.exists() && f.isFile();
		}
		catch (e) {
			return false;
		}
	},

	_newestImage(dir) {
		try {
			let dirFile = Zotero.File.pathToFile(dir);
			if (!dirFile.exists() || !dirFile.isDirectory()) {
				return null;
			}
			let entries = dirFile.directoryEntries;
			let best = null;
			let bestTime = -1;
			while (entries.hasMoreElements()) {
				let f = entries.getNext();
				// 新版 Gecko 的 getNext() 已经是 nsIFile，老版本才需要 QI
				try {
					if (f && typeof f.QueryInterface === 'function') {
						f.QueryInterface(Ci.nsIFile);
					}
				}
				catch (e) {}
				if (!f || !f.isFile()) {
					continue;
				}
				let name = f.leafName;
				if (name.charAt(0) === '.') {
					continue;
				}
				let ext = name.split('.').pop().toLowerCase();
				if (this.IMAGE_EXTS.indexOf(ext) === -1) {
					continue;
				}
				let t = f.lastModifiedTime;
				if (t > bestTime) {
					bestTime = t;
					best = f.path;
				}
			}
			return best;
		}
		catch (e) {
			Zotero.logError(e);
			return null;
		}
	},

	/**
	 * 当前应该显示哪张图
	 */
	async resolveImage() {
		let dir = await this.ensureDir();
		let auto = this.getPref('auto');

		if (!auto) {
			let p = this.getPref('image');
			if (p && this._fileExists(p)) {
				return p;
			}
		}

		let newest = this._newestImage(dir);
		if (newest) {
			// 记录一下，方便首选项面板显示"当前图片"
			if (this.getPref('image') !== newest) {
				this.setPref('image', newest);
			}
			return newest;
		}

		let p = this.getPref('image');
		return (p && this._fileExists(p)) ? p : null;
	},

	// ------------------------------------------------------------ 图片转 data URL

	async _readBinaryString(path) {
		// 优先用 XHR 分块读取（大图更省内存），失败再退回 Zotero 自带 API
		try {
			let bin = await new Promise((resolve, reject) => {
				let xhr = new XMLHttpRequest();
				xhr.open('GET', Services.io.newFileURI(Zotero.File.pathToFile(path)).spec, true);
				xhr.responseType = 'arraybuffer';
				xhr.onload = () => {
					try {
						if (!xhr.response) {
							reject(new Error('empty response'));
							return;
						}
						let arr = new Uint8Array(xhr.response);
						let chunk = 0x8000;
						let parts = [];
						for (let i = 0; i < arr.length; i += chunk) {
							parts.push(String.fromCharCode.apply(null, arr.subarray(i, i + chunk)));
						}
						resolve(parts.join(''));
					}
					catch (e) {
						reject(e);
					}
				};
				xhr.onerror = () => reject(new Error('无法读取文件：' + path));
				xhr.send();
			});
			if (bin) {
				return bin;
			}
		}
		catch (e) {
			Zotero.debug('[Wallpaper] XHR 读取失败，改用 Zotero.File：' + e);
		}

		return await Zotero.File.getBinaryContentsAsync(path);
	},

	async getImageURL(path) {
		let f;
		try {
			f = Zotero.File.pathToFile(path);
		}
		catch (e) {
			return null;
		}
		if (!f.exists() || !f.isFile()) {
			return null;
		}

		let key = path + '|' + f.lastModifiedTime + '|' + f.fileSize;
		if (this._cache && this._cache.key === key) {
			return this._cache.url;
		}

		let bin = await this._readBinaryString(path);
		let b64;
		try {
			b64 = btoa(bin);
		}
		catch (e) {
			Zotero.logError(e);
			return null;
		}

		let ext = path.split('.').pop().toLowerCase();
		let mime = this.MIME[ext];
		if (!mime) {
			mime = (await this._sniffMime(path)) || 'image/png';
		}
		let url = 'data:' + mime + ';base64,' + b64;

		this._cache = { key, url };
		return url;
	},

	// ---------------------------------------------------------------- 样式注入

	_getStyleText() {
		return `
#zotero-items-pane { position: relative !important; }

#${this.LAYER_ID} {
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	z-index: 0;
	overflow: hidden;
	pointer-events: none;
}

#${this.IMAGE_ID} {
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-repeat: no-repeat;
	background-position: center center;
	background-size: cover;
	opacity: var(--zw-opacity, 0.55);
	filter: blur(var(--zw-blur, 0px));
}

#zotero-items-tree {
	position: relative;
	z-index: 1;
}

/* ---- Zotero 7.1+ / 10.x：虚拟表格 ---- */
#zotero-items-tree,
#zotero-items-tree .virtualized-table,
#zotero-items-tree .virtualized-table-body,
#zotero-items-tree .virtualized-table-header {
	background-color: transparent !important;
	background-image: none !important;
}

#zotero-items-tree .virtualized-table .row:not(.selected) {
	background-color: transparent !important;
}

#zotero-items-tree .virtualized-table .row.selected {
	background-color: color-mix(in srgb, var(--color-accent, #3b82f6) 72%, transparent) !important;
}

/* ---- Zotero 7.0：XUL tree（旧版兜底） ---- */
#zotero-items-tree treechildren {
	background-color: transparent !important;
}
#zotero-items-tree treechildren::-moz-tree-row {
	background-color: transparent !important;
}
`;
	},

	_injectStyle(doc) {
		if (doc.getElementById(this.STYLE_ID)) {
			return;
		}
		let style = doc.createElementNS('http://www.w3.org/1999/xhtml', 'style');
		style.id = this.STYLE_ID;
		style.textContent = this._getStyleText();
		doc.documentElement.appendChild(style);
	},

	// ------------------------------------------------------------------ 窗口

	_findPane(doc) {
		let pane = doc.getElementById('zotero-items-pane');
		if (pane) {
			return pane;
		}
		let tree = doc.getElementById('zotero-items-tree');
		if (tree && tree.parentNode) {
			return tree.parentNode;
		}
		return null;
	},

	addToWindow(win, attempt) {
		attempt = attempt || 0;
		if (!win || !win.document) {
			return;
		}
		let doc = win.document;

		let pane = this._findPane(doc);
		if (!pane) {
			// 主窗口可能还没建好，稍后重试
			if (attempt < 40) {
				try {
					win.setTimeout(() => {
						try {
							this.addToWindow(win, attempt + 1);
						}
						catch (e) {
							Zotero.logError(e);
						}
					}, 250);
				}
				catch (e) {}
			}
			return;
		}

		try {
			this._injectStyle(doc);

			let layer = doc.getElementById(this.LAYER_ID);
			if (!layer) {
				// 让壁纸层相对「条目列表」定位
				try {
					pane.style.setProperty('position', 'relative', 'important');
				}
				catch (e) {}

				layer = doc.createElementNS('http://www.w3.org/1999/xhtml', 'div');
				layer.id = this.LAYER_ID;

				let image = doc.createElementNS('http://www.w3.org/1999/xhtml', 'div');
				image.id = this.IMAGE_ID;
				layer.appendChild(image);

				pane.insertBefore(layer, pane.firstChild);
			}

			this._addMenuItem(win);

			if (this._windows.indexOf(win) === -1) {
				this._windows.push(win);
			}

			this.log('layer ready, pane=' + (pane.id || pane.localName));
			this._update(win);
		}
		catch (e) {
			Zotero.logError(e);
		}
	},

	removeFromWindow(win) {
		try {
			let doc = win.document;
			if (!doc) {
				return;
			}
			let layer = doc.getElementById(this.LAYER_ID);
			if (layer) {
				layer.remove();
			}
			let style = doc.getElementById(this.STYLE_ID);
			if (style) {
				style.remove();
			}
			let menu = doc.getElementById('zw-menu-settings');
			if (menu) {
				menu.remove();
			}
			let sep = doc.getElementById('zw-menu-sep');
			if (sep) {
				sep.remove();
			}
		}
		catch (e) {
			Zotero.logError(e);
		}
		let idx = this._windows.indexOf(win);
		if (idx !== -1) {
			this._windows.splice(idx, 1);
		}
	},

	_addMenuItem(win) {
		let doc = win.document;
		if (doc.getElementById('zw-menu-settings')) {
			return;
		}
		let popup = doc.getElementById('menu_ToolsPopup');
		if (!popup || !doc.createXULElement) {
			return;
		}
		try {
			let sep = doc.createXULElement('menuseparator');
			sep.id = 'zw-menu-sep';
			popup.appendChild(sep);

			let item = doc.createXULElement('menuitem');
			item.id = 'zw-menu-settings';
			item.setAttribute('label', '背景壁纸设置…');
			item.addEventListener('command', () => {
				try {
					Zotero.Utilities.Internal.openPreferences('zotero-wallpaper-pane');
				}
				catch (e) {
					Zotero.logError(e);
				}
			});
			popup.appendChild(item);
		}
		catch (e) {
			Zotero.logError(e);
		}
	},

	// ------------------------------------------------------------------ 渲染

	_update(win) {
		let doc = win.document;
		let layer = doc.getElementById(this.LAYER_ID);
		if (!layer) {
			return;
		}

		if (!this.getPref('enabled')) {
			layer.style.display = 'none';
			return;
		}
		layer.style.display = '';

		let image = doc.getElementById(this.IMAGE_ID);
		if (!image) {
			return;
		}

		let opacity = this.getPref('opacity');
		let blur = this.getPref('blur');
		if (opacity < 0) opacity = 0;
		if (opacity > 100) opacity = 100;
		if (blur < 0) blur = 0;

		image.style.setProperty('--zw-opacity', String(opacity / 100));
		image.style.setProperty('--zw-blur', blur + 'px');
		image.style.transform = blur > 0 ? 'scale(1.04)' : '';

		let fit = this.getPref('fit');
		switch (fit) {
			case 'contain':
				image.style.backgroundSize = 'contain';
				image.style.backgroundRepeat = 'no-repeat';
				break;
			case 'tile':
				image.style.backgroundSize = 'auto';
				image.style.backgroundRepeat = 'repeat';
				break;
			case 'stretch':
				image.style.backgroundSize = '100% 100%';
				image.style.backgroundRepeat = 'no-repeat';
				break;
			default:
				image.style.backgroundSize = 'cover';
				image.style.backgroundRepeat = 'no-repeat';
		}

		this._applyImage(image).catch(e => Zotero.logError(e));
	},

	async _applyImage(image) {
		let path = await this.resolveImage();
		if (!path) {
			image.removeAttribute('data-zw-sig');
			image.style.backgroundImage = 'none';
			this.log('no image found in ' + this.getDir());
			return;
		}
		let url = await this.getImageURL(path);
		if (!url) {
			image.removeAttribute('data-zw-sig');
			image.style.backgroundImage = 'none';
			return;
		}

		// 用一个很短的签名判断是否需要重新设置（避免每次刷新都写一次巨大的 data URL）
		let sig = url.length + '|' + url.slice(-48);
		if (image.getAttribute('data-zw-sig') === sig) {
			this._appliedSig = this._fileSig(path);
			return;
		}
		image.setAttribute('data-zw-sig', sig);
		image.style.backgroundImage = 'url("' + url + '")';
		this._appliedSig = this._fileSig(path);
		this.log('applied image: ' + path + ' (' + Math.round(url.length / 1024) + 'KB data url)');
	},

	refreshAll() {
		if (this._refreshTimer) {
			clearTimeout(this._refreshTimer);
		}
		this._refreshTimer = setTimeout(() => {
			this._refreshTimer = null;
			for (let win of this._windows.slice()) {
				try {
					this._update(win);
				}
				catch (e) {
					Zotero.logError(e);
				}
			}
		}, 60);
	},

	// -------------------------------------------------------------- 文件选择器

	/**
	 * 取 nsIFilePicker 上的常量（不同 Gecko 版本可能缺失）
	 */
	_fpConst(name, fallback) {
		try {
			let v = Ci.nsIFilePicker[name];
			if (typeof v === 'number') {
				return v;
			}
		}
		catch (e) {}
		return fallback;
	},

	/**
	 * 弹一次文件选择器。
	 * Zotero 7（旧 Gecko）：init(Window, ...)，open() 同步返回状态码
	 * Zotero 10（Gecko 140）：init(browsingContext, ...)，open(callback) 回调返回
	 * 这里两种都兼容。
	 *
	 * @return {Promise<String|null>} 选中路径；用户取消返回 null
	 */
	async _showPicker(win, { title, mode, filters, displayDir }) {
		let fp = Cc['@mozilla.org/filepicker;1'].createInstance(Ci.nsIFilePicker);

		// --- 1. init：优先 browsingContext，退回 Window
		let inited = false;
		try {
			if (win && win.browsingContext) {
				fp.init(win.browsingContext, title, mode);
				inited = true;
			}
		}
		catch (e) {
			inited = false;
		}
		if (!inited) {
			fp.init(win, title, mode);
		}

		// --- 2. 过滤器（第一个 append 的会成为默认）
		try {
			if (filters && filters.length) {
				for (let f of filters) {
					fp.appendFilter(f.title, f.filter);
				}
			}
			fp.appendFilters(this._fpConst('filterAll', 0x001));
		}
		catch (e) {
			this.log('appendFilter 失败（不影响使用）：' + e);
		}

		// --- 3. 初始目录
		if (displayDir) {
			try {
				let d = Zotero.File.pathToFile(displayDir);
				if (d.exists() && d.isDirectory()) {
					fp.displayDirectory = d;
				}
			}
			catch (e) {}
		}

		// --- 4. show
		let rv = await new Promise((resolve, reject) => {
			let settled = false;
			let done = (code) => {
				if (settled) {
					return;
				}
				settled = true;
				resolve(code);
			};
			try {
				let ret = fp.open(done);
				// 旧版会同步返回状态码
				if (typeof ret === 'number') {
					done(ret);
				}
			}
			catch (e) {
				reject(e);
			}
		});

		if (rv !== this._fpConst('returnOK', 0)) {
			return null;
		}
		try {
			return fp.file ? fp.file.path : null;
		}
		catch (e) {
			return null;
		}
	},

	/**
	 * 依次尝试用「首选项窗口 → 主窗口」做父窗口，直到弹出选择器
	 */
	async _pickPath(parentWin, opts) {
		let wins = [];
		if (parentWin) {
			wins.push(parentWin);
		}
		try {
			let m = Zotero.getMainWindow();
			if (m && wins.indexOf(m) === -1) {
				wins.push(m);
			}
		}
		catch (e) {}

		let lastErr = null;
		for (let win of wins) {
			try {
				return await this._showPicker(win, opts);
			}
			catch (e) {
				lastErr = e;
				this.log('选择器打开失败（父窗口 ' + (win && win.location) + '）：' + e);
			}
		}
		throw lastErr || new Error('无法打开文件选择器');
	},

	/** 当前文件夹路径，不存在时返回 null */
	_safeDir() {
		try {
			let d = this.getDir();
			let f = Zotero.File.pathToFile(d);
			return (f.exists() && f.isDirectory()) ? d : null;
		}
		catch (e) {
			return null;
		}
	},

	_filterString() {
		return this.IMAGE_EXTS.map(e => '*.' + e).join('; ');
	},

	_join(dir, name) {
		try {
			if (typeof PathUtils !== 'undefined' && PathUtils.join) {
				return PathUtils.join(dir, name);
			}
		}
		catch (e) {}
		let sep = dir.indexOf('/') !== -1 && dir.indexOf('\\') === -1 ? '/' : '\\';
		return dir.replace(/[\\\/]+$/, '') + sep + name;
	},

	/** 读文件开头若干字节，用来嗅探图片格式 */
	async _readHead(path, n) {
		try {
			if (typeof IOUtils !== 'undefined' && IOUtils.read) {
				return await IOUtils.read(path, n);
			}
		}
		catch (e) {}
		try {
			let bin = await Zotero.File.getBinaryContentsAsync(path);
			let len = Math.min(n, bin.length);
			let out = new Uint8Array(len);
			for (let i = 0; i < len; i++) {
				out[i] = bin.charCodeAt(i) & 0xFF;
			}
			return out;
		}
		catch (e) {
			return null;
		}
	},

	/** 按文件头判断 MIME，认不出来返回 null */
	async _sniffMime(path) {
		let b = await this._readHead(path, 256);
		if (!b || b.length < 4) {
			return null;
		}
		if (b[0] === 0xFF && b[1] === 0xD8 && b[2] === 0xFF) {
			return 'image/jpeg';
		}
		if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4E && b[3] === 0x47) {
			return 'image/png';
		}
		if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) {
			return 'image/gif';
		}
		if (b[0] === 0x42 && b[1] === 0x4D) {
			return 'image/bmp';
		}
		if (b.length >= 12
			&& b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46
			&& b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) {
			return 'image/webp';
		}
		if (b.length >= 12) {
			let ftyp = String.fromCharCode(b[4], b[5], b[6], b[7]);
			if (ftyp === 'ftyp') {
				let brand = String.fromCharCode(b[8], b[9], b[10], b[11]);
				if (/^avi[fs]$/.test(brand)) {
					return 'image/avif';
				}
				if (/^(heic|heix|hevc|mif1|msf1)$/.test(brand)) {
					return 'image/heic';
				}
			}
		}
		// SVG 是文本，看开头有没有 xml / svg 声明
		let head = '';
		for (let i = 0; i < Math.min(b.length, 256); i++) {
			head += String.fromCharCode(b[i]);
		}
		if (/^\s*<(\?xml|!--|svg)/i.test(head)) {
			return 'image/svg+xml';
		}
		return null;
	},

	/** 这个文件到底能不能当图片用 */
	async isImageFile(path) {
		let ext = (String(path).split('.').pop() || '').toLowerCase();
		if (this.MIME[ext]) {
			return true;
		}
		return !!(await this._sniffMime(path));
	},

	/**
	 * 把选中的图片复制进壁纸文件夹（已在文件夹里则原样返回），
	 * 重名时自动加序号，不覆盖已有文件。
	 */
	async _importImage(srcPath, dir) {
		let srcFile = Zotero.File.pathToFile(srcPath);
		let dirFile = Zotero.File.pathToFile(dir);

		try {
			if (srcFile.parent && dirFile && srcFile.parent.path === dirFile.path) {
				return srcPath;
			}
		}
		catch (e) {}

		let leaf = srcFile.leafName;
		let dot = leaf.lastIndexOf('.');
		let base = dot > 0 ? leaf.slice(0, dot) : leaf;
		let ext = dot > 0 ? leaf.slice(dot + 1) : 'png';

		let name = leaf;
		let destPath = this._join(dir, name);
		let n = 2;
		while (this._fileExists(destPath) && n <= 999) {
			name = base + ' (' + n + ').' + ext;
			destPath = this._join(dir, name);
			n++;
		}

		try {
			if (typeof IOUtils !== 'undefined' && IOUtils.copy) {
				await IOUtils.copy(srcPath, destPath);
				return destPath;
			}
		}
		catch (e) {
			this.log('IOUtils.copy 失败，改用 copyTo：' + e);
		}

		try {
			srcFile.copyTo(dirFile, name);
			return destPath;
		}
		catch (e) {
			Zotero.logError(e);
			// 实在复制不进去，就直接引用原位置的图片
			return srcPath;
		}
	},

	// ---------------------------------------------------------------- 面板调用

	/**
	 * 「选择图片…」：挑一张图 → 复制进壁纸文件夹 → 立刻生效
	 * @return {Promise<{ok:Boolean, path?:String, error?:String, cancelled?:Boolean}>}
	 */
	async chooseImage(parentWin) {
		try {
			let srcPath = await this._pickPath(parentWin, {
				title: '选择壁纸图片',
				mode: this._fpConst('modeOpen', 0),
				filters: [{ title: '图片文件', filter: this._filterString() }],
				displayDir: this._safeDir(),
			});

			if (!srcPath) {
				return { ok: false, cancelled: true };
			}

			let srcFile = Zotero.File.pathToFile(srcPath);
			if (!srcFile.exists() || !srcFile.isFile()) {
				return { ok: false, error: '选中的不是文件：' + srcPath };
			}
			if (!(await this.isImageFile(srcPath))) {
				return {
					ok: false,
					error: '「' + srcFile.leafName + '」不是支持的图片格式（'
						+ this.IMAGE_EXTS.join(' / ') + '）。',
				};
			}

			let dir = await this.ensureDir();
			let destPath = await this._importImage(srcPath, dir);

			this._cache = null;
			this.setPref('image', destPath);
			// 明确挑了一张图，就不再按「文件夹里最新」自动切换，避免刚选完又被顶掉
			this.setPref('auto', false);
			this.refreshAll();

			this.log('chooseImage → ' + destPath);
			return {
				ok: true,
				path: destPath,
				copied: destPath !== srcPath,
				size: srcFile.fileSize,
			};
		}
		catch (e) {
			Zotero.logError(e);
			return { ok: false, error: (e && e.message) ? e.message : String(e) };
		}
	},

	/**
	 * 「更改文件夹…」：挑一个文件夹当壁纸目录
	 */
	async chooseFolder(parentWin) {
		try {
			let dirPath = await this._pickPath(parentWin, {
				title: '选择壁纸文件夹',
				mode: this._fpConst('modeGetFolder', 2),
				displayDir: this._safeDir(),
			});

			if (!dirPath) {
				return { ok: false, cancelled: true };
			}

			let f = Zotero.File.pathToFile(dirPath);
			if (!f.exists() || !f.isDirectory()) {
				return { ok: false, error: '请选择一个文件夹，而不是文件。' };
			}

			this._cache = null;
			this.setPref('image', '');
			this.setPref('dir', dirPath);
			this.setPref('auto', true);
			await this.ensureDir();
			this.refreshAll();

			this.log('chooseFolder → ' + dirPath);
			let newest = this._newestImage(dirPath);
			return { ok: true, path: dirPath, image: newest };
		}
		catch (e) {
			Zotero.logError(e);
			return { ok: false, error: (e && e.message) ? e.message : String(e) };
		}
	},

	/** 「打开文件夹」：在资源管理器 / 访达里打开壁纸目录 */
	async openFolder() {
		let dir = this.getDir();
		try {
			await this.ensureDir();
			let f = Zotero.File.pathToFile(dir);
			if (!f.exists() || !f.isDirectory()) {
				return { ok: false, error: '文件夹不存在：' + dir };
			}

			// 打开目录本身
			try {
				Zotero.launchFile(f);
				return { ok: true, path: dir };
			}
			catch (e) {
				this.log('launchFile 失败：' + e);
			}

			// 退一步：在父目录里定位它
			try {
				f.reveal();
				return { ok: true, path: dir };
			}
			catch (e) {
				this.log('reveal 失败：' + e);
			}

			// 再退一步：交给 Zotero 自己的实现
			await Zotero.File.reveal(dir);
			return { ok: true, path: dir };
		}
		catch (e) {
			Zotero.logError(e);
			return { ok: false, error: (e && e.message) ? e.message : String(e) };
		}
	},

	resetAppearance() {
		this.setPref('opacity', this.DEFAULTS.opacity);
		this.setPref('blur', this.DEFAULTS.blur);
		this.setPref('fit', this.DEFAULTS.fit);
		this.refreshAll();
	},
};
