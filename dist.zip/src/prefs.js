/* Zotero Wallpaper - 默认首选项 */
pref("extensions.zotero.wallpaper.enabled", true);
pref("extensions.zotero.wallpaper.dir", "D:\\A aiwork\\zotero插件\\wallpapers");
pref("extensions.zotero.wallpaper.auto", true);
pref("extensions.zotero.wallpaper.image", "");
pref("extensions.zotero.wallpaper.opacity", 55);
pref("extensions.zotero.wallpaper.blur", 0);
pref("extensions.zotero.wallpaper.fit", "cover");
pref("extensions.zotero.wallpaper.debug", false);
