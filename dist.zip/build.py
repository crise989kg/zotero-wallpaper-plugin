"""打包 Zotero Wallpaper 插件为 .xpi

用法：  python build.py
产物：  dist/zotero-wallpaper-<version>.xpi
"""

import json
import os
import struct
import zlib
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
DIST = os.path.join(ROOT, "dist")
WALLPAPERS = os.path.join(ROOT, "wallpapers")


def png_chunk(tag, data):
    return (
        struct.pack(">I", len(data))
        + tag
        + data
        + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    )


def write_gradient_png(path, width=1920, height=1080):
    """生成一张柔和的渐变示例壁纸（纯标准库，无需 Pillow）"""
    c1 = (176, 208, 240)   # 左上：淡蓝
    c2 = (226, 214, 244)   # 右下：淡紫
    rows = []
    for y in range(height):
        ty = y / (height - 1)
        row = bytearray()
        row.append(0)  # filter: none
        for x in range(width):
            t = (x / (width - 1) * 0.65) + (ty * 0.35)
            # 加一点纵向明暗，避免死板
            t = min(1.0, max(0.0, t))
            r = int(c1[0] + (c2[0] - c1[0]) * t)
            g = int(c1[1] + (c2[1] - c1[1]) * t)
            b = int(c1[2] + (c2[2] - c1[2]) * t)
            row += bytes((r, g, b))
        rows.append(bytes(row))

    raw = b"".join(rows)
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    png = b"\x89PNG\r\n\x1a\n"
    png += png_chunk(b"IHDR", ihdr)
    png += png_chunk(b"IDAT", zlib.compress(raw, 9))
    png += png_chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(png)


def ensure_wallpapers():
    os.makedirs(WALLPAPERS, exist_ok=True)
    images = [
        n for n in os.listdir(WALLPAPERS)
        if os.path.splitext(n)[1].lower() in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".avif")
    ]
    if not images:
        sample = os.path.join(WALLPAPERS, "示例壁纸-可删除.png")
        write_gradient_png(sample)
        print("已生成示例壁纸:", sample)
    readme = os.path.join(WALLPAPERS, "把图片放进这个文件夹.txt")
    if not os.path.exists(readme):
        with open(readme, "w", encoding="utf-8") as f:
            f.write(
                "把想当壁纸的图片（jpg / png / webp / gif / bmp / avif）直接放进这个文件夹即可。\n"
                "插件会自动使用「最近修改」的那一张。\n"
                "也可以在 Zotero「编辑 → 设置 → 背景壁纸」里手动选择图片、调节不透明度。\n"
            )


def build():
    with open(os.path.join(SRC, "manifest.json"), "r", encoding="utf-8") as f:
        manifest = json.load(f)
    version = manifest["version"]

    os.makedirs(DIST, exist_ok=True)
    out = os.path.join(DIST, f"zotero-wallpaper-{version}.xpi")
    if os.path.exists(out):
        os.remove(out)

    files = []
    for base, _dirs, names in os.walk(SRC):
        for name in names:
            full = os.path.join(base, name)
            rel = os.path.relpath(full, SRC).replace("\\", "/")
            files.append((full, rel))
    files.sort(key=lambda x: x[1])

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for full, rel in files:
            z.write(full, rel)

    print(f"打包完成: {out}")
    print(f"包含 {len(files)} 个文件:")
    for _full, rel in files:
        print("   ", rel)
    return out


if __name__ == "__main__":
    ensure_wallpapers()
    build()
